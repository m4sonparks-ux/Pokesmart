package com.pokesmartsort;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.provider.DocumentsContract;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static class Card {
        Uri uri; String name, group, source, pokemonName="";
        Card(Uri u, String n) { uri=u; name=n; source=n.toLowerCase(Locale.ROOT); group=classify(source); }
    }
    static class DexEntry {
        int id; String name, url;
        DexEntry(int i, String n, String u) { id=i; name=n; url=u; }
        String displayName() { return titleCase(name.replace('-', ' ')); }
    }

    final ArrayList<Card> cards = new ArrayList<>();
    final ArrayList<DexEntry> pokemon = new ArrayList<>();
    final ExecutorService io = Executors.newSingleThreadExecutor();
    final Handler main = new Handler(Looper.getMainLooper());
    LinearLayout root, content, list;
    TextView count, status;
    Spinner sorter;
    String sortMode="Smart sort", currentScreen="cards";
    EditText dexSearch;
    LinearLayout dexResults;
    boolean dexLoaded=false, dexLoading=false;

    static String classify(String s) {
        if (s.matches(".*(charizard|flareon|moltres|fire|pyro).*")) return "Fire";
        if (s.matches(".*(blastoise|squirtle|psyduck|vaporeon|water|gyarados).*")) return "Water";
        if (s.matches(".*(pikachu|raichu|zapdos|electric|jolteon).*")) return "Electric";
        if (s.matches(".*(bulbasaur|ivysaur|venusaur|oddish|grass|leaf).*")) return "Grass";
        if (s.matches(".*(mewtwo|mew|abra|psychic|alakazam).*")) return "Psychic";
        if (s.matches(".*(dragonite|dratini|dragon|rayquaza).*")) return "Dragon";
        if (s.matches(".*(trainer|supporter|item|stadium).*")) return "Trainer";
        return "Unsorted";
    }
    static String titleCase(String s) {
        String[] a=s.split(" "); StringBuilder b=new StringBuilder();
        for(String p:a) { if(p.isEmpty()) continue; if(b.length()>0)b.append(' '); b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)); }
        return b.toString();
    }
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(32,33,36)); getWindow().setNavigationBarColor(Color.rgb(32,33,36)); loadSavedCards(); buildShell(); }
    @Override protected void onDestroy() { super.onDestroy(); io.shutdownNow(); }
    int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, int color) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    LinearLayout vertical() { LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); return x; }
    LinearLayout horizontal() { LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.HORIZONTAL); x.setGravity(Gravity.CENTER_VERTICAL); return x; }
    Button button(String label, Runnable action) { Button b=new Button(this); b.setText(label); b.setOnClickListener(v->action.run()); return b; }

    void buildShell() {
        root=vertical(); root.setPadding(dp(14),dp(10),dp(14),dp(7)); root.setBackgroundColor(Color.rgb(248,249,250)); setContentView(root);
        TextView title=text("Poké Smart Sort",25,Color.rgb(32,33,36)); title.setTypeface(null,Typeface.BOLD); root.addView(title);
        TextView subtitle=text("Pokémon card organizer & Pokédex",13,Color.DKGRAY); root.addView(subtitle);
        LinearLayout nav=horizontal(); nav.setPadding(0,dp(4),0,dp(4));
        nav.addView(button("My Cards",()->showCards()),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button("Pokédex",()->showDex()),new LinearLayout.LayoutParams(0,-2,1));
        root.addView(nav); View line=new View(this); line.setBackgroundColor(Color.LTGRAY); root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        content=vertical(); root.addView(content,new LinearLayout.LayoutParams(-1,0,1)); showCards();
    }
    void showCards() { currentScreen="cards"; content.removeAllViews();
        Button folder=button("📁  Choose / scan Pokémon cards folder",()->pickCardFolder()); content.addView(folder);
        Button add=button("＋  Import selected card images",()->pickImages()); content.addView(add);
        String savedFolder=getSharedPreferences("collection",MODE_PRIVATE).getString("folderUri","");
        TextView folderHint=text(savedFolder.isEmpty()?"Folder not selected yet":"Saved card folder: "+savedFolder,11,Color.GRAY); folderHint.setPadding(0,dp(3),0,dp(5)); content.addView(folderHint);
        if(!savedFolder.isEmpty()) content.addView(button("↻  Scan saved folder now",()->scanSavedFolder()));
        sorter=new Spinner(this);
        String[] modes={"Smart sort","Pokémon A–Z","Type / category","Name A–Z","Duplicate filenames","Unsorted first"};
        sorter.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,modes));
        sorter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){sortMode=modes[pos];renderCards();}
        }); content.addView(sorter);
        count=text("0 images imported",14,Color.DKGRAY); count.setPadding(0,dp(7),0,dp(6)); content.addView(count);
        ScrollView scroll=new ScrollView(this); content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        list=vertical(); scroll.addView(list);
        TextView note=text("Tip: use Tag on an image to assign the exact Pokémon. Smart sort can then group your card images by Pokédex entry.",12,Color.GRAY); note.setPadding(0,dp(8),0,0); content.addView(note);
        renderCards();
    }
    void showDex() {
        currentScreen="dex"; content.removeAllViews();
        dexSearch=new EditText(this); dexSearch.setSingleLine(true); dexSearch.setHint("Search all Pokémon by name"); content.addView(dexSearch);
        status=text(dexLoading?"Loading Pokédex…":(dexLoaded?pokemon.size()+" Pokémon loaded":"Connect to the internet to load the full Pokédex"),13,Color.DKGRAY); status.setPadding(0,dp(5),0,dp(6)); content.addView(status);
        ScrollView scroll=new ScrollView(this); content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); dexResults=vertical(); scroll.addView(dexResults);
        dexSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderDexResults(s.toString());} public void afterTextChanged(Editable e){}});
        if(!dexLoaded) loadDex(); else renderDexResults("");
    }
    void loadDex() {
        if(dexLoading) return; dexLoading=true; if(status!=null)status.setText("Loading full species list…");
        io.execute(()->{
            try {
                JSONObject json=getJson("https://pokeapi.co/api/v2/pokemon-species?limit=2000"); JSONArray results=json.getJSONArray("results"); ArrayList<DexEntry> temp=new ArrayList<>();
                for(int i=0;i<results.length();i++) { JSONObject o=results.getJSONObject(i); String name=o.getString("name"); String u=o.getString("url"); int id=parseId(u); temp.add(new DexEntry(id,name,u)); }
                temp.sort(Comparator.comparingInt(a->a.id));
                main.post(()->{pokemon.clear(); pokemon.addAll(temp); dexLoaded=true; dexLoading=false; autoAssociateCards(); if(currentScreen.equals("dex")){if(status!=null)status.setText(pokemon.size()+" Pokémon loaded • tap one for details"); renderDexResults(dexSearch==null?"":dexSearch.getText().toString());} if(currentScreen.equals("cards"))renderCards();});
            } catch(Exception e) { main.post(()->{dexLoading=false; if(status!=null)status.setText("Could not load Pokédex. Check your connection and reopen this tab."); Toast.makeText(this,"Pokédex could not load. Check internet access.",Toast.LENGTH_LONG).show();}); }
        });
    }
    int parseId(String url) { try { String x=url.replaceAll("/$",""); return Integer.parseInt(x.substring(x.lastIndexOf('/')+1)); } catch(Exception e){ return 0; } }
    void renderDexResults(String query) {
        if(dexResults==null) return; dexResults.removeAllViews(); if(!dexLoaded) return;
        String q=query.trim().toLowerCase(Locale.ROOT); int shown=0;
        for(DexEntry p:pokemon) {
            if(!q.isEmpty() && !(p.name.contains(q)||p.displayName().toLowerCase(Locale.ROOT).contains(q)||String.valueOf(p.id).equals(q))) continue;
            LinearLayout row=horizontal(); row.setPadding(dp(10),dp(7),dp(8),dp(7)); row.setBackgroundColor(Color.WHITE);
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(54)); rp.bottomMargin=dp(4); dexResults.addView(row,rp);
            TextView id=text(String.format(Locale.US,"#%04d",p.id),13,Color.GRAY); row.addView(id,new LinearLayout.LayoutParams(dp(55),-2));
            TextView n=text(p.displayName(),16,Color.rgb(32,33,36)); n.setTypeface(null,Typeface.BOLD); row.addView(n,new LinearLayout.LayoutParams(0,-2,1));
            TextView go=text("›",28,Color.DKGRAY); row.addView(go); row.setOnClickListener(v->showPokemonDetail(p));
            shown++; if(shown>=180 && !q.isEmpty()) break;
        }
        if(shown==0){TextView empty=text("No Pokémon matched that search.",14,Color.GRAY); empty.setPadding(dp(8),dp(12),0,0); dexResults.addView(empty);}
        else if(q.isEmpty()){TextView info=text("Showing first 180 entries. Search by name or Pokédex number to find others.",12,Color.GRAY); info.setPadding(dp(5),dp(6),0,dp(6)); dexResults.addView(info);}
    }
    void showPokemonDetail(DexEntry p) {
        currentScreen="detail"; content.removeAllViews(); content.addView(button("‹ Back to Pokédex",()->showDex()));
        LinearLayout body=vertical(); ScrollView sc=new ScrollView(this); content.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); sc.addView(body);
        TextView heading=text(String.format(Locale.US,"#%04d  %s",p.id,p.displayName()),24,Color.rgb(32,33,36)); heading.setTypeface(null,Typeface.BOLD); heading.setPadding(0,dp(8),0,dp(4)); body.addView(heading);
        LinearLayout imageRow=horizontal(); body.addView(imageRow);
        ImageView sprite=new ImageView(this); sprite.setScaleType(ImageView.ScaleType.FIT_CENTER); imageRow.addView(sprite,new LinearLayout.LayoutParams(dp(150),dp(150)));
        String spriteUrl="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/"+p.id+".png";
        io.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(spriteUrl).openConnection(); c.setConnectTimeout(8000);c.setReadTimeout(8000); c.connect(); Bitmap b=BitmapFactory.decodeStream(c.getInputStream()); c.disconnect(); if(b!=null)main.post(()->{if(currentScreen.equals("detail"))sprite.setImageBitmap(b);});}catch(Exception ignored){}});
        TextView facts=text("Loading species data…",14,Color.DKGRAY); facts.setPadding(dp(8),dp(8),0,dp(8)); imageRow.addView(facts,new LinearLayout.LayoutParams(0,-2,1));
        TextView intro=text("Species, game facts, and base stats",17,Color.rgb(32,33,36)); intro.setTypeface(null,Typeface.BOLD); body.addView(intro);
        TextView flavor=text("",14,Color.DKGRAY); flavor.setPadding(0,dp(5),0,dp(12)); body.addView(flavor);
        Button wiki=button("Bulbapedia: full article in app",()->showBulbapedia(p)); body.addView(wiki);
        body.addView(button("Open Bulbapedia search in browser",()->openBulbapedia(p)));
        TextView attribution=text("Data provided by PokéAPI. Bulbapedia opens in your browser for its full articles, images, citations, and broader franchise information. This app does not reproduce full Bulbapedia articles.",12,Color.GRAY); attribution.setPadding(0,dp(10),0,dp(8)); body.addView(attribution);
        io.execute(()->{
            try {
                JSONObject species=getJson("https://pokeapi.co/api/v2/pokemon-species/"+p.id+"/");
                JSONObject poke=getJson("https://pokeapi.co/api/v2/pokemon/"+p.id+"/");
                String genus="Unknown"; JSONArray genera=species.getJSONArray("genera");
                for(int i=0;i<genera.length();i++){JSONObject x=genera.getJSONObject(i);if("en".equals(x.getJSONObject("language").getString("name"))){genus=x.getString("genus");break;}}
                String types=""; JSONArray ta=poke.getJSONArray("types"); for(int i=0;i<ta.length();i++){if(i>0)types+=" / ";types+=titleCase(ta.getJSONObject(i).getJSONObject("type").getString("name"));}
                String abilities=""; JSONArray ab=poke.getJSONArray("abilities");for(int i=0;i<ab.length();i++){if(i>0)abilities+=", ";abilities+=titleCase(ab.getJSONObject(i).getJSONObject("ability").getString("name").replace('-',' '));}
                String stats="";JSONArray sa=poke.getJSONArray("stats");for(int i=0;i<sa.length();i++){JSONObject st=sa.getJSONObject(i);String sn=st.getJSONObject("stat").getString("name");stats+=titleCase(sn.replace('-',' '))+": "+st.getInt("base_stat")+"\n";}
                String flavorText="No English Pokédex description available."; JSONArray entries=species.getJSONArray("flavor_text_entries");for(int i=entries.length()-1;i>=0;i--){JSONObject x=entries.getJSONObject(i);if("en".equals(x.getJSONObject("language").getString("name"))){flavorText=x.getString("flavor_text").replace('\n',' ').replace('\f',' ');break;}}
                String habitat=species.isNull("habitat")?"Unknown":titleCase(species.getJSONObject("habitat").getString("name").replace('-',' '));
                String generation=titleCase(species.getJSONObject("generation").getString("name").replace('-',' '));
                String catchRate=species.optString("capture_rate","?"); String height=(poke.optInt("height",0)*10)+" cm"; String weight=String.format(Locale.US,"%.1f kg",poke.optInt("weight",0)/10.0);
                String f="Category: "+genus+"\nType: "+types+"\nHeight: "+height+"\nWeight: "+weight+"\nHabitat: "+habitat+"\nGeneration: "+generation+"\nCapture rate: "+catchRate+"\nAbilities: "+abilities+"\n\nBase stats\n"+stats;
                final String ff=f, fl=flavorText;
                main.post(()->{if(currentScreen.equals("detail")){facts.setText(ff);flavor.setText("Pokédex description\n"+fl);}});
            } catch(Exception e){main.post(()->{if(currentScreen.equals("detail")){facts.setText("Couldn't load details. Check your connection.");flavor.setText("You can still open the Bulbapedia article below.");}});}
        });
    }
    void openBulbapedia(DexEntry p) {
        try {String term=p.displayName()+" (Pokémon)"; String url="https://bulbapedia.bulbagarden.net/wiki/Special:Search?search="+URLEncoder.encode(term,"UTF-8"); startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
        catch(Exception e){Toast.makeText(this,"Couldn't open a browser.",Toast.LENGTH_SHORT).show();}
    }
    JSONObject getJson(String urlString) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(urlString).openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(12000); c.setRequestProperty("User-Agent","PokeSmartSort-Android/1.0");
        try(InputStream in=c.getInputStream()){byte[] buf=new byte[8192]; java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream(); int n;while((n=in.read(buf))>0)out.write(buf,0,n);return new JSONObject(out.toString("UTF-8"));} finally {c.disconnect();}
    }
    void autoAssociateCards() {
        if(pokemon.isEmpty())return; boolean changed=false;
        for(Card c:cards) if(c.pokemonName.isEmpty()){
            DexEntry best=null; int bestLen=0;
            for(DexEntry p:pokemon){String n=p.name.toLowerCase(Locale.ROOT); if(n.length()<4)continue; String spaced=n.replace('-',' '); if((c.source.contains(n)||c.source.contains(spaced)) && n.length()>bestLen){best=p;bestLen=n.length();}}
            if(best!=null){c.pokemonName=best.name;changed=true;}
        }
        if(changed)saveCards();
    }
    void pickImages() { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,42); }
    String displayName(Uri uri) { String result="Pokémon card image"; try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int idx=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(idx>=0)result=c.getString(idx);}}catch(Exception ignored){} return result; }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) { super.onActivityResult(requestCode,resultCode,data); if(resultCode!=RESULT_OK||data==null)return;
        if(requestCode==43 && data.getData()!=null) {
            Uri tree=data.getData(); int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try { getContentResolver().takePersistableUriPermission(tree,flags); } catch(Exception ignored) {}
            getSharedPreferences("collection",MODE_PRIVATE).edit().putString("folderUri",tree.toString()).apply();
            Toast.makeText(this,"Card folder saved. Scanning images…",Toast.LENGTH_LONG).show(); scanFolder(tree); return;
        }
        if(requestCode!=42)return;
        if(data.getClipData()!=null){for(int n=0;n<data.getClipData().getItemCount();n++)addUri(data.getClipData().getItemAt(n).getUri());} else if(data.getData()!=null)addUri(data.getData());
        autoAssociateCards(); renderCards();
    }
    void pickCardFolder() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { Uri initial=DocumentsContract.buildDocumentUri("com.android.externalstorage.documents","primary:Pictures/pokemon cards"); i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,initial); } catch(Exception ignored) {}
        startActivityForResult(i,43);
    }
    void scanSavedFolder() {
        String value=getSharedPreferences("collection",MODE_PRIVATE).getString("folderUri","");
        if(value.isEmpty()){pickCardFolder();return;} scanFolder(Uri.parse(value));
    }
    void scanFolder(Uri tree) {
        io.execute(()->{
            int[] found={0}; scanDocumentTree(tree,found,0);
            main.post(()->{saveCards();autoAssociateCards();renderCards();Toast.makeText(this,"Folder scan complete: "+found[0]+" new image(s) added.",Toast.LENGTH_LONG).show();});
        });
    }
    void scanDocumentTree(Uri tree,int[] found,int depth) {
        if(depth>8)return;
        try {
            String docId=DocumentsContract.getDocumentId(tree);
            Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,docId);
            try(Cursor cur=getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)) {
                if(cur==null)return;
                while(cur.moveToNext()) {
                    String id=cur.getString(0), name=cur.getString(1), mime=cur.getString(2);
                    Uri doc=DocumentsContract.buildDocumentUriUsingTree(tree,id);
                    if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) scanDocumentTree(doc,found,depth+1);
                    else if(mime!=null&&mime.startsWith("image/")) {
                        boolean exists=false; synchronized(cards){for(Card c:cards)if(c.uri.equals(doc)){exists=true;break;}}
                        if(!exists){ synchronized(cards){cards.add(new Card(doc,name==null?"Card image":name));} found[0]++; }
                    }
                }
            }
        } catch(Exception ignored) { }
    }
    void addUri(Uri u) { try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){} for(Card c:cards)if(c.uri.equals(u))return;cards.add(new Card(u,displayName(u))); saveCards(); }
    void loadSavedCards() {
        try {
            String saved=getSharedPreferences("collection",MODE_PRIVATE).getString("cards","[]"); JSONArray arr=new JSONArray(saved);
            for(int i=0;i<arr.length();i++){JSONObject o=arr.getJSONObject(i); Uri u=Uri.parse(o.getString("uri")); Card c=new Card(u,o.optString("name","Card image")); c.group=o.optString("group","Unsorted"); c.pokemonName=o.optString("pokemon",""); cards.add(c);}
        } catch(Exception ignored) { }
    }
    void saveCards() {
        try {JSONArray arr=new JSONArray(); for(Card c:cards){JSONObject o=new JSONObject();o.put("uri",c.uri.toString());o.put("name",c.name);o.put("group",c.group);o.put("pokemon",c.pokemonName);arr.put(o);}getSharedPreferences("collection",MODE_PRIVATE).edit().putString("cards",arr.toString()).apply();} catch(Exception ignored) { }
    }
    void showBulbapedia(DexEntry p) {
        currentScreen="wiki"; content.removeAllViews();
        LinearLayout top=horizontal(); top.addView(button("‹ Back to Pokémon",()->showPokemonDetail(p)),new LinearLayout.LayoutParams(0,-2,1));
        top.addView(button("Open browser",()->openBulbapedia(p))); content.addView(top);
        TextView label=text("Bulbapedia · "+p.displayName(),17,Color.rgb(32,33,36)); label.setTypeface(null,Typeface.BOLD); label.setPadding(0,dp(6),0,dp(6)); content.addView(label);
        WebView web=new WebView(this); web.getSettings().setJavaScriptEnabled(false); web.setWebViewClient(new WebViewClient()); content.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        try {String article=p.displayName()+" (Pokémon)"; String slug=URLEncoder.encode(article,"UTF-8").replace("+","_"); web.loadUrl("https://bulbapedia.bulbagarden.net/wiki/"+slug);}catch(Exception e){openBulbapedia(p);}
    }
    void renderCards() {
        if(list==null)return; list.removeAllViews(); ArrayList<Card> shown=new ArrayList<>(cards);
        if(sortMode.equals("Name A–Z"))shown.sort(Comparator.comparing(c->c.name.toLowerCase(Locale.ROOT)));
        else if(sortMode.equals("Type / category"))shown.sort(Comparator.comparing(c->c.group));
        else if(sortMode.equals("Pokémon A–Z"))shown.sort(Comparator.comparing((Card c)->c.pokemonName.isEmpty()?"~~~~":c.pokemonName).thenComparing(c->c.name.toLowerCase(Locale.ROOT)));
        else if(sortMode.equals("Unsorted first"))shown.sort(Comparator.comparing((Card c)->!c.group.equals("Unsorted")));
        else if(sortMode.equals("Duplicate filenames")){HashMap<String,Integer> freq=new HashMap<>();for(Card c:shown)freq.put(c.name.toLowerCase(Locale.ROOT),freq.getOrDefault(c.name.toLowerCase(Locale.ROOT),0)+1);shown.removeIf(c->freq.get(c.name.toLowerCase(Locale.ROOT))<2);}
        else shown.sort(Comparator.comparing((Card c)->c.pokemonName.isEmpty()).thenComparing(c->c.pokemonName).thenComparing(c->c.group).thenComparing(c->c.name.toLowerCase(Locale.ROOT)));
        if(count!=null)count.setText(shown.size()+" images shown • "+cards.size()+" total imported");
        if(shown.isEmpty()){TextView empty=text(cards.isEmpty()?"Import your card images to start building your collection.":"No images match this view yet.",15,Color.DKGRAY);empty.setPadding(0,dp(18),0,dp(18));list.addView(empty);return;}
        for(Card c:shown){LinearLayout row=horizontal();row.setPadding(dp(7),dp(7),dp(4),dp(7));row.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(92));rp.bottomMargin=dp(6);list.addView(row,rp);
            ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);try{image.setImageURI(c.uri);}catch(Exception ignored){}row.addView(image,new LinearLayout.LayoutParams(dp(62),dp(76)));
            LinearLayout details=vertical();details.setPadding(dp(9),0,dp(2),0);row.addView(details,new LinearLayout.LayoutParams(0,-2,1));TextView name=text(c.name,13,Color.rgb(32,33,36));name.setTypeface(null,Typeface.BOLD);details.addView(name);
            String assigned=c.pokemonName.isEmpty()?"Pokémon: not assigned":"Pokémon: "+titleCase(c.pokemonName.replace('-',' '));details.addView(text(assigned,12,Color.rgb(45,90,150)));details.addView(text("Category: "+c.group,11,Color.DKGRAY));
            Button tag=button("Tag",()->showTagOptions(c));row.addView(tag);
        }
    }
    void showTagOptions(Card c) {new AlertDialog.Builder(this).setTitle("Organize "+c.name).setItems(new String[]{"Assign Pokémon","Change category","Clear Pokémon assignment"},(d,which)->{if(which==0)pickPokemonForCard(c);else if(which==1)chooseCategory(c);else{c.pokemonName="";saveCards();renderCards();}}).show();}
    void pickPokemonForCard(Card c) {
        if(!dexLoaded){new AlertDialog.Builder(this).setMessage("Load the Pokédex first so you can choose from all Pokémon.").setPositiveButton("Open Pokédex",(d,w)->showDex()).setNegativeButton("Cancel",null).show(); return;}
        LinearLayout box=vertical();EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Search Pokémon…");box.addView(input);
        ListView lv=new ListView(this);box.addView(lv,new LinearLayout.LayoutParams(-1,dp(380)));
        ArrayList<DexEntry> filtered=new ArrayList<>(pokemon);ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names(filtered));lv.setAdapter(adapter);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Assign Pokémon").setView(box).setNegativeButton("Cancel",null).create();
        input.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int co,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){String q=s.toString().toLowerCase(Locale.ROOT);filtered.clear();for(DexEntry p:pokemon)if(p.name.contains(q)||p.displayName().toLowerCase(Locale.ROOT).contains(q)||String.valueOf(p.id).equals(q)){filtered.add(p);if(filtered.size()>=250)break;}adapter.clear();adapter.addAll(names(filtered));adapter.notifyDataSetChanged();}public void afterTextChanged(Editable e){}});
        lv.setOnItemClickListener((parent,view,pos,id)->{if(pos<filtered.size()){c.pokemonName=filtered.get(pos).name;saveCards();dialog.dismiss();renderCards();}});dialog.show();dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.92),-2);
    }
    ArrayList<String> names(ArrayList<DexEntry> entries){ArrayList<String> n=new ArrayList<>();for(DexEntry p:entries)n.add(String.format(Locale.US,"#%04d  %s",p.id,p.displayName()));return n;}
    void chooseCategory(Card c) {String[] categories={"Fire","Water","Electric","Grass","Psychic","Dragon","Trainer","Unsorted"};new AlertDialog.Builder(this).setTitle("Set category").setItems(categories,(d,which)->{c.group=categories[which];saveCards();renderCards();}).show();}
}
