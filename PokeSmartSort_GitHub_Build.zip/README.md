# Poké Smart Sort — GitHub cloud-build project

This is the Android source project for Poké Smart Sort, including the My Cards screen, local folder picker, Pokédex backed by PokéAPI, and Bulbapedia article links.

## Build an APK from an Android tablet (GitHub Actions)

1. Download and extract this ZIP on your tablet. If your file manager cannot extract ZIP files, use any trusted archive app.
2. Sign in or create a GitHub account at https://github.com.
3. Create a new **public or private repository** named `PokeSmartSort`. Do not add a README or license during repository creation.
4. In the repository, use **Add file → Upload files** and upload the *contents* of the extracted `PokeSmartSort` folder, including the hidden `.github/workflows/android.yml` file. Make sure `settings.gradle`, `build.gradle`, `gradle.properties`, and the `app` folder are at the repository root. If GitHub's mobile page hides the upload option, use your browser menu and select **Desktop site**.
5. Commit the uploaded files to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build Poké Smart Sort APK** and tap **Run workflow** if it hasn't started automatically.
7. Wait for the workflow to finish with a green checkmark. Open the completed run, scroll to **Artifacts**, and download `poke-smart-sort-debug-apk`.
8. Extract that artifact ZIP. It contains `app-debug.apk`. Tap the APK to install it. Android may ask you to allow installs from your browser or file manager; only allow this for the app you used to download the file.

GitHub Actions usage limits and account policies apply. A public repository is not required; a private repository is fine if your account's Actions allowance supports the build.

## What the workflow does

The `.github/workflows/android.yml` workflow installs Java 17, Android SDK platform 35, and Gradle 8.9, runs `gradle assembleDebug`, and uploads the generated debug APK as a downloadable workflow artifact. No cloud server needs to be rented.

## App notes

- The app asks you to select your card folder through Android's system folder picker. Navigate to `Internal storage/Pictures/pokemon cards` and grant access.
- Pokémon list and details use PokéAPI and require internet access.
- Bulbapedia articles are opened from Bulbapedia rather than copied into the app.
- Filename-based matching and duplicate detection are basic helpers, not image recognition.
- This source project has not been compiled or device-tested in this environment. The cloud workflow will reveal any compile errors.
